#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:globals.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;

vec4 lightFactor() {
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    return sample_lightmap(Sampler2, UV2);
#else
    return vec4(1.0);
#endif
}

void finalizeFog(vec4 vertex) {
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(vertex.xyz);
    cylindricalVertexDistance = fog_cylindrical_distance(vertex.xyz);
#endif
}

#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.))

void applyProjection(inout vec4 vertex) {
    gl_Position = ProjMat * ModelViewMat * vertex;
}

void applyColorTexture() {
    vertexColor = Color * lightFactor();
}

void applyHueColor() {
    vertexColor = hue(gl_Position.x + GameTime * 1000.) * lightFactor();
}

void applyWaveEffect() {
    gl_Position.y += sin(GameTime * 12000. + (gl_Position.x * 6.)) / 150.;
}

// gorne wierzcholki glifu to 0 i 3, dolne to 1 i 2
bool isTopVertex() {
    int id = gl_VertexID & 3;
    return id == 0 || id == 3;
}

void applyGradient(vec3 topColor, vec3 bottomColor) {
    vec3 c = isTopVertex() ? topColor : bottomColor;
    vertexColor = vec4(c, Color.a) * lightFactor();
}

void processRainbowEffect(inout vec4 vertex) {
    applyProjection(vertex);
    applyHueColor();
    finalizeFog(vertex);
}

void processWavyEffect(inout vec4 vertex) {
    applyProjection(vertex);
    applyColorTexture();
    applyWaveEffect();
    finalizeFog(vertex);
}

void processWavyRainbowEffect(inout vec4 vertex) {
    applyProjection(vertex);
    applyWaveEffect();
    applyHueColor();
    finalizeFog(vertex);
}

void processBouncyEffect(inout vec4 vertex) {
    applyColorTexture();
    float vertexId = mod(float(gl_VertexID), 4.);
    if (vertex.z <= 0.) {
        if (vertexId == 3. || vertexId == 0.) {
            vertex.y += cos(GameTime * 12000. / 4.) * .1;
            vertex.y += max(cos(GameTime * 12000. / 4.) * .1, 0.);
        }
    } else {
        if (vertexId == 3. || vertexId == 0.) {
            vertex.y -= cos(GameTime * 12000. / 4.) * 3.;
            vertex.y -= max(cos(GameTime * 12000. / 4.) * 4., 0.);
        }
    }
    applyProjection(vertex);
    finalizeFog(vertex);
}

void processBouncyRainbowEffect(inout vec4 vertex) {
    float vertexId = mod(float(gl_VertexID), 4.);
    if (vertex.z <= 0.) {
        if (vertexId == 3. || vertexId == 0.) {
            vertex.y += cos(GameTime * 12000. / 4.) * .1;
            vertex.y += max(cos(GameTime * 12000. / 4.) * .1, 0.);
        }
    } else {
        if (vertexId == 3. || vertexId == 0.) {
            vertex.y -= cos(GameTime * 12000. / 4.) * 3.;
            vertex.y -= max(cos(GameTime * 12000. / 4.) * 4., 0.);
        }
    }
    applyProjection(vertex);
    applyHueColor();
    finalizeFog(vertex);
}

void processBlinkingEffect(inout vec4 vertex, float speed) {
    applyProjection(vertex);
    float blink = abs(sin(GameTime * 12000. * speed));
    vertexColor = Color * blink * lightFactor();
    finalizeFog(vertex);
}

void processNoShadow(inout vec4 vertex) {
    applyProjection(vertex);
    applyColorTexture();
    vertexColor = vec4(1, 1, 1, vertexColor.a);
    finalizeFog(vertex);
}

// ---- nowe efekty ----

// Zloty gradient: jasne zloto u gory, ciemne u dolu, powolny blask wzdluz tekstu
void processGoldEffect(inout vec4 vertex) {
    applyProjection(vertex);
    float s = 0.5 + 0.5 * sin(GameTime * 6000. - gl_Position.x * 10.);
    vec3 top = mix(vec3(1.00, 0.90, 0.45), vec3(1.00, 0.97, 0.72), s);
    vec3 bottom = mix(vec3(0.80, 0.50, 0.05), vec3(0.95, 0.68, 0.12), s);
    applyGradient(top, bottom);
    finalizeFog(vertex);
}

// Czerwony gradient: ten sam efekt co zloty, w czerwieni
void processRedEffect(inout vec4 vertex) {
    applyProjection(vertex);
    float s = 0.5 + 0.5 * sin(GameTime * 6000. - gl_Position.x * 10.);
    vec3 top = mix(vec3(1.00, 0.45, 0.40), vec3(1.00, 0.70, 0.62), s);
    vec3 bottom = mix(vec3(0.62, 0.03, 0.03), vec3(0.85, 0.15, 0.12), s);
    applyGradient(top, bottom);
    finalizeFog(vertex);
}

// Legendarny: bursztynowo-pomaranczowy gradient z blyskiem (cieplejszy niz zloty)
void processLegendaryEffect(inout vec4 vertex) {
    applyProjection(vertex);
    float s = 0.5 + 0.5 * sin(GameTime * 6000. - gl_Position.x * 10.);
    vec3 top = mix(vec3(1.00, 0.78, 0.22), vec3(1.00, 0.90, 0.50), s);
    vec3 bottom = mix(vec3(0.95, 0.42, 0.00), vec3(1.00, 0.60, 0.08), s);
    applyGradient(top, bottom);
    finalizeFog(vertex);
}

// Epicki: fioletowy gradient z blyskiem
void processEpicEffect(inout vec4 vertex) {
    applyProjection(vertex);
    float s = 0.5 + 0.5 * sin(GameTime * 6000. - gl_Position.x * 10.);
    vec3 top = mix(vec3(0.78, 0.50, 1.00), vec3(0.90, 0.72, 1.00), s);
    vec3 bottom = mix(vec3(0.42, 0.08, 0.72), vec3(0.60, 0.25, 0.90), s);
    applyGradient(top, bottom);
    finalizeFog(vertex);
}

float glyphHash(float seed) {
    return fract(sin(seed * 12.9898) * 43758.5453);
}

// Blaze: plomienie, gorne krawedzie liter "liza" w gore w roznym tempie, kolory migocza miedzy zoltym a rozpalona czerwienia
void processBlazeEffect(inout vec4 vertex) {
    applyProjection(vertex);
    float h = glyphHash(float(gl_VertexID >> 2));
    float f = 0.5 + 0.5 * sin(GameTime * 24000. + h * 6.2831);
    float f2 = 0.5 + 0.5 * sin(GameTime * 14000. + h * 17.0);
    if (isTopVertex()) {
        gl_Position.y += 0.003 + 0.007 * f;
    }
    vec3 top = mix(vec3(1.00, 0.88, 0.15), vec3(1.00, 0.60, 0.05), f);
    vec3 bottom = mix(vec3(0.95, 0.22, 0.00), vec3(1.00, 0.45, 0.02), f2);
    applyGradient(top, bottom);
    finalizeFog(vertex);
}

// Szkielet: kosc (kremowa biel do szarosci), litery co chwile grzechocza (krotkie drgania)
void processSkeletonEffect(inout vec4 vertex) {
    applyProjection(vertex);
    float gid = float(gl_VertexID >> 2);
    float ticks = GameTime * 24000.;
    float t = floor(ticks / 2.);
    float rattle = step(fract(ticks / 30.), 0.25);
    float r1 = glyphHash(gid + t * 7.13);
    float r2 = glyphHash(gid * 3.1 + t * 3.77);
    gl_Position.x += (r1 - 0.5) * 0.008 * rattle;
    gl_Position.y += (r2 - 0.5) * 0.004 * rattle;
    applyGradient(vec3(0.96, 0.96, 0.88), vec3(0.62, 0.62, 0.57));
    finalizeFog(vertex);
}

// ---- efekty pod spawnery ----
float gameTicks() { return GameTime * 24000.; }
float glyphId() { return float(gl_VertexID >> 2); }

// Kurczak: biel do zoltego, litery dziobia w dol w roznym momencie
void processChickenEffect(inout vec4 vertex) {
    applyProjection(vertex);
    float h = glyphHash(glyphId());
    float peck = max(0., sin(gameTicks() * 0.45 + h * 6.2831));
    if (isTopVertex()) gl_Position.y -= peck * peck * 0.007;
    applyGradient(vec3(1.0, 1.0, 0.96), vec3(1.0, 0.78, 0.30));
    finalizeFog(vertex);
}

// Krowa: biale i brazowe lacie (losowo na litere), spokojne kolysanie
void processCowEffect(inout vec4 vertex) {
    applyProjection(vertex);
    float gid = glyphId();
    float spot = step(0.5, glyphHash(gid * 1.7 + 3.0));
    gl_Position.y += sin(gameTicks() * 0.15 + gid * 0.8) * 0.0025;
    vec3 top = mix(vec3(0.97, 0.97, 0.97), vec3(0.50, 0.32, 0.18), spot);
    vec3 bottom = mix(vec3(0.78, 0.78, 0.78), vec3(0.32, 0.20, 0.10), spot);
    applyGradient(top, bottom);
    finalizeFog(vertex);
}

// Pszczola: zolte i ciemne paski (co druga litera), brzeczenie i unoszenie sie
void processBeeEffect(inout vec4 vertex) {
    applyProjection(vertex);
    float gid = glyphId();
    float t = gameTicks();
    float dark = mod(gid, 2.);
    gl_Position.x += sin(t * 3.1 + gid * 5.) * 0.0015;
    gl_Position.y += sin(t * 2.3 + gid * 3.) * 0.0020 + sin(t * 0.2 + gid) * 0.003;
    vec3 top = mix(vec3(1.00, 0.82, 0.10), vec3(0.30, 0.22, 0.06), dark);
    vec3 bottom = mix(vec3(0.95, 0.62, 0.00), vec3(0.12, 0.09, 0.03), dark);
    applyGradient(top, bottom);
    finalizeFog(vertex);
}

// Zombie: zielona skora i niebieska koszula, litery chwieja sie jak powloczacy nogami
void processZombieEffect(inout vec4 vertex) {
    applyProjection(vertex);
    float h = glyphHash(glyphId());
    if (isTopVertex()) gl_Position.x += sin(gameTicks() * 0.12 + h * 6.2831) * 0.005;
    applyGradient(vec3(0.45, 0.72, 0.35), vec3(0.20, 0.32, 0.62));
    finalizeFog(vertex);
}

// Creaking: ciemne drewno, skokowy (zamrazany) ruch i pulsujace pomaranczowe oczy
void processCreakingEffect(inout vec4 vertex) {
    applyProjection(vertex);
    float gid = glyphId();
    float t = gameTicks();
    float r = glyphHash(gid + floor(t / 12.) * 5.3);
    if (isTopVertex()) gl_Position.x += (r - 0.5) * 0.006;
    float eye = pow(max(0., sin(t * 0.06 + gid * 0.9)), 8.);
    vec3 top = mix(vec3(0.46, 0.38, 0.33), vec3(1.00, 0.50, 0.12), eye);
    applyGradient(top, vec3(0.18, 0.14, 0.12));
    finalizeFog(vertex);
}

// Guardian: morska zielen, pulsujaca poswiata i kolce
void processGuardianEffect(inout vec4 vertex) {
    applyProjection(vertex);
    float gid = glyphId();
    float t = gameTicks();
    float pulse = 0.5 + 0.5 * sin(t * 0.2 - gid * 0.7);
    gl_Position.y += sin(t * 0.08 + gid * 0.5) * 0.003;
    if (isTopVertex()) gl_Position.y += pulse * 0.004;
    vec3 top = mix(vec3(0.35, 0.80, 0.75), vec3(0.75, 1.00, 0.95), pulse);
    applyGradient(top, vec3(0.08, 0.40, 0.42));
    finalizeFog(vertex);
}

// Elder Guardian: ciezka wolna fala, rzadki blysk klatwy
void processElderGuardianEffect(inout vec4 vertex) {
    applyProjection(vertex);
    float t = gameTicks();
    gl_Position.y += sin(t * 0.07 - gl_Position.x * 6.) * 0.006;
    float flash = pow(max(0., sin(t * 0.04)), 12.);
    vec3 top = mix(vec3(0.90, 0.62, 0.38), vec3(1.00, 0.95, 0.90), flash);
    vec3 bottom = mix(vec3(0.30, 0.48, 0.50), vec3(0.80, 0.70, 0.90), flash);
    applyGradient(top, bottom);
    finalizeFog(vertex);
}

// Warden: ciemny blekit, jasny turkus pulsuje jak bicie serca (dwa uderzenia), lekkie drzenie
void processWardenEffect(inout vec4 vertex) {
    applyProjection(vertex);
    float gid = glyphId();
    float t = gameTicks();
    float beat = pow(max(0., sin(t * 0.35)), 6.) + 0.6 * pow(max(0., sin(t * 0.35 - 1.1)), 6.);
    float glow = clamp(beat, 0., 1.);
    gl_Position.x += (glyphHash(gid + floor(t)) - 0.5) * 0.003 * glow;
    vec3 top = mix(vec3(0.10, 0.38, 0.42), vec3(0.25, 1.00, 0.88), glow);
    vec3 bottom = mix(vec3(0.03, 0.10, 0.14), vec3(0.05, 0.45, 0.42), glow);
    applyGradient(top, bottom);
    finalizeFog(vertex);
}

// Wither: czern i szarosc, drzenie, blyski bialo-niebieskiego ladunku
void processWitherEffect(inout vec4 vertex) {
    applyProjection(vertex);
    float gid = glyphId();
    float t = gameTicks();
    gl_Position.x += sin(t * 2.7 + gid * 3.) * 0.0012;
    gl_Position.y += sin(t * 3.3 + gid * 5.) * 0.0012;
    float charge = pow(0.5 + 0.5 * sin(t * 0.09 + gid * 0.3), 10.);
    vec3 top = mix(vec3(0.36, 0.36, 0.42), vec3(0.85, 0.90, 1.00), charge);
    vec3 bottom = mix(vec3(0.10, 0.10, 0.13), vec3(0.35, 0.40, 0.60), charge);
    applyGradient(top, bottom);
    finalizeFog(vertex);
}

// Enderdragon: fiolet i magenta, falowanie jak machanie skrzydel i przesuwajacy sie blask
void processEnderDragonEffect(inout vec4 vertex) {
    applyProjection(vertex);
    float t = gameTicks();
    gl_Position.y += sin(t * 0.12 - gl_Position.x * 5.) * 0.007;
    float band = pow(0.5 + 0.5 * sin(t * 0.15 - gl_Position.x * 14.), 6.);
    vec3 top = mix(vec3(0.65, 0.25, 0.95), vec3(1.00, 0.55, 1.00), band);
    vec3 bottom = mix(vec3(0.18, 0.03, 0.34), vec3(0.55, 0.10, 0.75), band);
    applyGradient(top, bottom);
    finalizeFog(vertex);
}

// Halloween: falujacy pomaranczowy gradient (zolty pomarancz do ciemnej dyni)
void processHalloweenEffect(inout vec4 vertex) {
    applyProjection(vertex);
    applyWaveEffect();
    float s = 0.5 + 0.5 * sin(GameTime * 6000. + gl_Position.x * 8.);
    vec3 top = mix(vec3(1.00, 0.80, 0.18), vec3(1.00, 0.58, 0.05), s);
    vec3 bottom = mix(vec3(0.95, 0.36, 0.00), vec3(0.72, 0.20, 0.00), s);
    applyGradient(top, bottom);
    finalizeFog(vertex);
}

// Sakura: falujacy rozowy gradient (platki, od bialego rozu do glebokiego rozu)
void processSakuraEffect(inout vec4 vertex) {
    applyProjection(vertex);
    applyWaveEffect();
    float s = 0.5 + 0.5 * sin(GameTime * 5000. + gl_Position.x * 7.);
    vec3 top = mix(vec3(1.00, 0.86, 0.92), vec3(1.00, 0.95, 0.97), s);
    vec3 bottom = mix(vec3(0.96, 0.42, 0.62), vec3(1.00, 0.60, 0.76), s);
    applyGradient(top, bottom);
    finalizeFog(vertex);
}

// Shiny: jasny gradient (biel do jasnego blekitu) z blyskiem przesuwajacym sie po tekscie
void processShinyEffect(inout vec4 vertex) {
    applyProjection(vertex);
    float s = fract(gl_Position.x * 1.2 - GameTime * 500.);
    float band = exp(-pow((s - 0.5) / 0.07, 2.));
    float twinkle = 0.5 + 0.5 * sin(GameTime * 20000. + gl_Position.x * 40.);
    float glint = band * (0.65 + 0.35 * twinkle);
    vec3 top = vec3(0.97, 0.99, 1.00);
    vec3 bottom = vec3(0.70, 0.83, 0.96);
    vec3 c = isTopVertex() ? top : bottom;
    c = min(c + glint * vec3(0.9, 0.9, 0.8), vec3(1.0));
    vertexColor = vec4(c, Color.a) * lightFactor();
    finalizeFog(vertex);
}

void applyTextEffects() {
    vec4 vertex = vec4(Position, 1.);
    ivec3 iColor = ivec3(Color.xyz * 255. + vec3(.5));

    // cienie tekstu (kolor / 4), rozpoznawane po przesunieciu w osi Z
    if (fract(Position.z) < .1) {
        if (iColor == ivec3(19, 23, 9)) {
            gl_Position = vec4(2, 2, 2, 1);
            applyColorTexture();
            finalizeFog(vertex);
            return;
        }
        if (iColor == ivec3(57, 63, 63)) {
            applyProjection(vertex);
            applyColorTexture();
            finalizeFog(vertex);
            return;
        }
        if (iColor == ivec3(57, 63, 62)) { processWavyEffect(vertex); return; }
        if (iColor == ivec3(57, 62, 63)) { processWavyEffect(vertex); return; }
        if (iColor == ivec3(57, 62, 62)) { processBouncyEffect(vertex); return; }
        if (iColor == ivec3(57, 61, 63)) { processBouncyEffect(vertex); return; }
        if (iColor == ivec3(57, 61, 62)) { processBlinkingEffect(vertex, .5); return; }
        // nowe: zloty i shiny maja zwykly cien, halloween i sakura cien falujacy
        if (iColor == ivec3(57, 60, 63) || iColor == ivec3(57, 59, 62) || iColor == ivec3(57, 58, 63) || iColor == ivec3(57, 58, 62) || iColor == ivec3(57, 57, 63) || iColor == ivec3(57, 56, 63) || iColor == ivec3(57, 56, 62) || iColor == ivec3(57, 55, 63) || iColor == ivec3(57, 55, 62) || iColor == ivec3(57, 54, 63) || iColor == ivec3(57, 54, 62) || iColor == ivec3(57, 53, 63) || iColor == ivec3(57, 53, 62) || iColor == ivec3(57, 52, 63) || iColor == ivec3(57, 52, 62) || iColor == ivec3(57, 51, 63) || iColor == ivec3(57, 51, 62)) {
            applyProjection(vertex);
            applyColorTexture();
            finalizeFog(vertex);
            return;
        }
        if (iColor == ivec3(57, 60, 62) || iColor == ivec3(57, 59, 63)) {
            processWavyEffect(vertex);
            return;
        }
    }

    if (iColor == ivec3(78, 92, 36)) { processNoShadow(vertex); return; }
    if (iColor == ivec3(230, 255, 254)) { processRainbowEffect(vertex); return; }
    if (iColor == ivec3(230, 255, 250)) { processWavyEffect(vertex); return; }
    if (iColor == ivec3(230, 251, 254)) { processWavyRainbowEffect(vertex); return; }
    if (iColor == ivec3(230, 251, 250)) { processBouncyEffect(vertex); return; }
    if (iColor == ivec3(230, 247, 254)) { processBouncyRainbowEffect(vertex); return; }
    if (iColor == ivec3(230, 247, 250)) { processBlinkingEffect(vertex, .5); return; }
    // nowe kolory wyzwalajace
    if (iColor == ivec3(230, 243, 254)) { processGoldEffect(vertex); return; }
    if (iColor == ivec3(230, 235, 254)) { processRedEffect(vertex); return; }
    if (iColor == ivec3(230, 235, 250)) { processLegendaryEffect(vertex); return; }
    if (iColor == ivec3(230, 231, 254)) { processEpicEffect(vertex); return; }
    if (iColor == ivec3(230, 227, 254)) { processBlazeEffect(vertex); return; }
    if (iColor == ivec3(230, 227, 250)) { processSkeletonEffect(vertex); return; }
    if (iColor == ivec3(230, 223, 254)) { processChickenEffect(vertex); return; }
    if (iColor == ivec3(230, 223, 250)) { processCowEffect(vertex); return; }
    if (iColor == ivec3(230, 219, 254)) { processBeeEffect(vertex); return; }
    if (iColor == ivec3(230, 219, 250)) { processZombieEffect(vertex); return; }
    if (iColor == ivec3(230, 215, 254)) { processCreakingEffect(vertex); return; }
    if (iColor == ivec3(230, 215, 250)) { processGuardianEffect(vertex); return; }
    if (iColor == ivec3(230, 211, 254)) { processElderGuardianEffect(vertex); return; }
    if (iColor == ivec3(230, 211, 250)) { processWardenEffect(vertex); return; }
    if (iColor == ivec3(230, 207, 254)) { processWitherEffect(vertex); return; }
    if (iColor == ivec3(230, 207, 250)) { processEnderDragonEffect(vertex); return; }
    if (iColor == ivec3(230, 243, 250)) { processHalloweenEffect(vertex); return; }
    if (iColor == ivec3(230, 239, 254)) { processSakuraEffect(vertex); return; }
    if (iColor == ivec3(230, 239, 250)) { processShinyEffect(vertex); return; }

    applyProjection(vertex);
    applyColorTexture();
    finalizeFog(vertex);
}

void main() {
    texCoord0 = UV0;
    applyTextEffects();
}
